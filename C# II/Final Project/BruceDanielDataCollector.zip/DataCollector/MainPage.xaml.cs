﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

/*
 * Daniel Bruce
 * 4/19/2022
 * This program tracks the distance a jellyfish has moved at consistent time intervals (the distance is actually a randomly generated number)
 * TODO: implement functionality to remember past units of measurment (might require data format restructure)
 * TODO: clean output of history such that junk data doesn't fill the screen when first starting collection
 * TODO: add time stamp to history entries
 */

namespace DataCollector
{

    public sealed partial class MainPage : Page
    {
		private MeasureLengthDevice jellyfishMovement = new MeasureLengthDevice(Unit.Imperial);//default unit is imperial
		
		public MainPage()
        {
            this.InitializeComponent();
			//the initial data binding
			historyDataBinding();
			this.jellyfishMovement.timeData.Tick+= measurmentTextUpdateHandler;
			historyListView.Opacity = 0;
		}
		//enables & disables collection respectively
		private void collectToggleButton_Checked(object sender, RoutedEventArgs e)
		{
			this.jellyfishMovement.StartCollecting();
		}

		private void collectToggleButton_Unchecked(object sender, RoutedEventArgs e)
		{
			this.jellyfishMovement.StopCollecting();
		}
		//toggle that makes the history visible
		private void displayHistoryToggleButton_Checked(object sender, RoutedEventArgs e)
		{
			historyListView.Opacity = 1;
		}

		private void displayHistoryToggleButton_Unchecked(object sender, RoutedEventArgs e)
		{
			historyListView.Opacity = 0;
		}
		//Update measurements
		private void measurmentTextUpdateHandler(object sender, object e)
		{
			//recent measurement
			recentMeasurementTextBox.Text = this.jellyfishMovement.mostRecentMeasure.ToString();
			//history
			historyDataBinding();
			//converted measurment
			if (jellyfishMovement.unitsToUse == Unit.Imperial)
			{
				convertedMeasurementTextBox.Text = this.jellyfishMovement.MetricValue().ToString();
			}
			else {
				convertedMeasurementTextBox.Text = this.jellyfishMovement.ImperialValue().ToString();
			}
		}
		//format raw data and bind historylistview to the formatted data
		private void historyDataBinding() {
			string[] measureHistory = new string[10];
			for (int i = 0 ; i < 10 ; i++) {
				//add raw data to string
				if (this.jellyfishMovement.GetRawData()[i] != 0) {
					measureHistory[i] = this.jellyfishMovement.GetRawData()[i].ToString();
					//add units of measurement
					if (jellyfishMovement.unitsToUse == Unit.Imperial)
					{
						measureHistory[i] += '″';
					}
					else {
						measureHistory[i] += "cm";
					}
				}
			}
			historyListView.ItemsSource = measureHistory;
		}

		private void inchesRadioButton_Checked(object sender, RoutedEventArgs e)
		{
			this.jellyfishMovement.setUnit(Unit.Imperial);
		}

		private void centimetersRadioButton_Checked(object sender, RoutedEventArgs e)
		{
			this.jellyfishMovement.setUnit(Unit.Metric);
		}
	}
}
