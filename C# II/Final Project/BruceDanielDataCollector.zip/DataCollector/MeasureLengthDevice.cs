﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Windows.UI.Xaml;//for dispatch timer



//This "device" tracks various length measurments in a table

namespace DataCollector
{
    class MeasureLengthDevice : Device, IMeasuringDevice
    {
        //class vars
        
        private int[] dataCaptured = new int[10];//max length 10, will probably replace with queue object when we go over those
        private const decimal INCH_CENTIMETER_CONVERSION = 2.54m;
        //properties														 
		private int _mostRecentMeasure;
        public int mostRecentMeasure
        {
            get => this._mostRecentMeasure;
            private set => this._mostRecentMeasure = value;
        }
        private DispatcherTimer _timeData = new DispatcherTimer(); //this will be used in mainpage.xaml.cs, but we need to control collection through the object, so it's here
        public DispatcherTimer timeData { 
            get => _timeData; 
            private set => _timeData = value; 
        }
        private Unit _unitsToUse;//determines base units
        public Unit unitsToUse { 
            get => _unitsToUse; 
            private set => _unitsToUse = value; 
        }

		//constructor
		public MeasureLengthDevice(Unit u) {
            this.unitsToUse = u;
            this.dataCaptured[0] = GetMeasurement();
            this.mostRecentMeasure = this.dataCaptured[0];//this is the first capture, so it's always the most recent
            this.timeData.Tick += captureData;//subscribe tick event to captureData
        }

        //methods
        public void setUnit(Unit u)
        {
            this.unitsToUse = u;
        }
        //Adds data to the datCaptured array, and manages it so that it functions like a queue
        public void captureData(object sender, object e) {
            int d = GetMeasurement();
            this.mostRecentMeasure = d;
            //array should never contain zero unless no value has been assigned, so check for zeros when looking for unnassigned indexes
            if (this.dataCaptured[0] != 0)
            {
                //check to see if array is full
                if (this.dataCaptured[9] != 0)
                {
                    //shift data forward in queue
                    push(this.dataCaptured);
                    //place new value at start of queue
                    this.dataCaptured[0] = d;
                }
                else {
                    //int filledArrayEnd = 0;
                    //loop through dataCaptured[] to find first empty spot
                    for (int i = 1; i < (this.dataCaptured.Length-1); i++)
                    {
                        
                        if (this.dataCaptured[i] == 0) {
                            //last value index found
                            //shift values forward
                            push(this.dataCaptured, i);
                            this.dataCaptured[0] = d;
                            break;
                        }
                    }
                }  
            }
            else {
                //fallback in case index 0 was not assigned for some reason
                this.dataCaptured[0] = d;
            }
        }
        //push queue forward to a certain distance
        private void push(int[] ar, int destination) {
            while(destination < 10)
            {
                ar[destination] = ar[destination - 1];
                destination++;
            }
        }
        //overload with no destination given, default to array length
        private void push(int[] ar)
        {
            for (int l = ar.Length - 1; l > 0; l--)
            {
                ar[l] = ar[l - 1];
            }
        }

        //interface-loaned methods
        public int[] GetRawData()
        {
            //this passes the array by reference, but we aren't changing any values when we use this, so this should be fine
            return this.dataCaptured;
        }
        //displays imperial and metric values respectively, regardless of what the base units are
        public decimal ImperialValue()
        {
            if (unitsToUse == Unit.Imperial)
            {
                return this.mostRecentMeasure;
            }
            else {
                return this.mostRecentMeasure * INCH_CENTIMETER_CONVERSION;
            }
        }

        public decimal MetricValue()
        {
            if (unitsToUse == Unit.Metric)
            {
                return this.mostRecentMeasure;
            }
            else
            {
                return this.mostRecentMeasure / INCH_CENTIMETER_CONVERSION;
            }
        }
        //activates and deactivates the timer respectively
        public void StartCollecting()
        {
            TimeSpan measInterv = new TimeSpan(0,0,1);
            this.timeData.Interval = measInterv;
            this.timeData.Start();
        }

        public void StopCollecting()
        {
            this.timeData.Stop();
        }

        
    }
}
