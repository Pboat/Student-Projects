﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Windows.UI.Xaml;//for dispatch timer


//This "device" tracks various length measurments in a table

namespace DataCollector
{
    class MeasureLengthDevice : Device, IMeasuringDevice
    {
        //class vars
        private Unit unitsToUse;//determines base units
        private int[] dataCaptured = new int[10];//max length 10, will probably replace with queue object when we go over those
        private int mostRecentMeasure;
        private const decimal INCH_CENTIMETER_CONVERSION = 2.54m;
        DispatcherTimer timeData = new DispatcherTimer(); //this will be used in mainpage.xaml.cs, but we need to control collection through the object, so it's here

        //constructor
        public MeasureLengthDevice(Unit u, int d) {
            this.unitsToUse = u;
            this.dataCaptured[0] = d;
            this.mostRecentMeasure = d;//this is the first capture, so it's always the most recent
        }
        //methods
        public void setUnit(Unit u)
        {
            this.unitsToUse = u;
        }
        //manages the dataCaptured array so that it functions like a queue
        public void captureData(int d) {
            //array should never contain zero unless no value has been assigned, so check for zeros when looking for unnassigned indexes
            if (dataCaptured[0] != 0)
            {
                //check to see if array is full
                if (dataCaptured[9] != 0)
                {
                    //shift data forward in queue
                    push(dataCaptured);
                    //place new value at start of queue
                    dataCaptured[0] = d;
                }
                else {
                    //int filledArrayEnd = 0;
                    //loop through dataCaptured[] to find first empty spot
                    for (int i = 1; i < (dataCaptured.Length-1)/*9*/; i++)
                    {
                        
                        if (dataCaptured[i] == 0) {
                            //last value index found
                            //shift values forward
                            push(dataCaptured, i);
                            dataCaptured[0] = d;
                            break;
                        }
                    }
                }  
            }
            else {
                //fallback in case index 0 was not assigned for some reason
                dataCaptured[0] = d;
            }
        }
        //push queue forward to a certain distance
        private void push(int[] ar, int destination) {
            for (; destination > 0; l--)
            {
                ar[destination] = ar[destination - 1];
            }
        }
        //overload with no destination given, default to array length
        private void push(int[] ar)
        {
            for (int l = ar.Length - 1; l > 0; l--)
            {
                ar[l] = ar[l - 1];
            }
        }

        //interface-loaned methods
        int[] IMeasuringDevice.GetRawData()
        {
            return this.dataCaptured;
        }
        //displays imperial and metric values respectively, regardless of what the base units are
        decimal IMeasuringDevice.ImperialValue()
        {
            if (unitsToUse == Unit.Imperial)
            {
                return mostRecentMeasure;
            }
            else {
                return mostRecentMeasure * INCH_CENTIMETER_CONVERSION;
            }
        }

        decimal IMeasuringDevice.MetricValue()
        {
            if (unitsToUse == Unit.Metric)
            {
                return mostRecentMeasure;
            }
            else
            {
                return mostRecentMeasure / INCH_CENTIMETER_CONVERSION;
            }
        }
        //activates and deactivates the timer respectivel
        void IMeasuringDevice.StartCollecting()
        {
            this.timeData.Start();
        }

        void IMeasuringDevice.StopCollecting()
        {
            this.timeData.Stop();
        }
    }
}
