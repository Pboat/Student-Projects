﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataCollector
{
    //for designating what kind of units of measurement should be used
    public enum Unit { Metric, Imperial};
}
